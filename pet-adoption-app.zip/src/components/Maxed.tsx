export function Maxed() {
  return (
    <div className="bottomText">
      <p>
        Maximum is reached <br></br> You can't put more than 5 pets for adoption
      </p>
    </div>
  );
}
export default Maxed;
