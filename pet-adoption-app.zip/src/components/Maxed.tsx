export function Maxed() {
  return (
    <div class="bottomText">
      <p>
        Maximum is reached <br></br> You can't put more than 5 pets for adoption
      </p>
    </div>
  );
}
export default Maxed;
