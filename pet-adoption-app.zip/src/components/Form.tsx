import { useAccount, useConnect, useDisconnect } from "wagmi";
import * as React from "react";
import { useState } from "react";
import { usePrepareContractWrite, useWaitForTransaction } from "wagmi";
import ABI from "./Abi.json";
import { useContractWrite } from "wagmi";
import { useContractRead } from "wagmi";

export function Form() {
  const [name, setName] = useState("");
  const [species, setSpecies] = useState("other");
  const [age, setAge] = useState("");
  const [vaccinated, setVaccinated] = useState(false);
  const { isConnected } = useAccount();
  const { address } = useAccount();

  const countRead = useContractRead({
    address: "0x25d01F0bc600690A11E44D593C34265d50eAEAb3",
    abi: ABI,
    functionName: "userStats",
    args: [address],
  });

  let userCount;
  let contractData = countRead.data;

  if (isConnected && contractData != undefined) {
    userCount = Number(contractData.petsAdded);
  }

  const { config } = usePrepareContractWrite({
    address: "0x25d01F0bc600690A11E44D593C34265d50eAEAb3",
    abi: ABI,
    functionName: "putForAdoption",
    args: [name, species, age, vaccinated],
  });

  const { data, error, write } = useContractWrite(config);

  const { isLoading, isSuccess, isError } = useWaitForTransaction({
    hash: data?.hash,
  });

  let wholeForm;
  let bottomForm;

  if (isConnected) {
    bottomForm = (
      <div>
        <button class="submit" onClick={() => write?.()}>
          SUBMIT
        </button>
      </div>
    );

    if (isLoading) {
      bottomForm = <div>submitting in progress...</div>;
    }
    if (isSuccess) {
      bottomForm = <div>submit successful</div>;
    }
    if (error) {
      bottomForm = <div>submit ERROR</div>;
    }
    if (isError) {
      bottomForm = <div>submit ERROR</div>;
    }
  } else {
    bottomForm = (
      <div class="bottomText">
        <p>Connect to submit !</p>
      </div>
    );
  }
  wholeForm = (
    <div class="container2">
      <div class="adoptionText">
        <p>Put for adoption</p>
      </div>
      <div class="formDiv">
        <div>
          <div class="nameField">
            <p class="inputLabel"> Name</p>
            <input
              class="inputSpace"
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>

          <div class="speciesField">
            <p class="inputLabel"> Species</p>
            <select
              class="dropDown"
              required
              value={species}
              onChange={(e) => setSpecies(e.target.value)}
            >
              <option value="dog">Dog</option>
              <option value="cat">Cat</option>
              <option value="other">Other</option>
            </select>
          </div>

          <div class="ageField">
            <p class="inputLabel"> Age</p>
            <input
              class="inputSpace"
              type="number"
              required
              value={age}
              onChange={(e) => setAge(e.target.value)}
            />
          </div>
          <div class="checkField">
            <p class="checkText"> Vaccinated</p>
            <input
              type="checkbox"
              class="myCheck"
              onChange={(e) => setVaccinated(e.target.checked)}
            />
          </div>
        </div>
      </div>
      <div class="connectWarn">{bottomForm}</div>
    </div>
  );

  return <>{wholeForm}</>;
}
export default Form;
