import { useAccount } from "wagmi";
import React, { useEffect, useState } from "react";
import { usePrepareContractWrite, useWaitForTransaction } from "wagmi";
import { useContractWrite } from "wagmi";
import { TableTest } from ".";
import { useContractRead } from "wagmi";
import { useSigner } from "wagmi";
import { ethers } from "ethers";
import ABI from "./Abi.json";
export function FullTable() {
  const { address, isConnected } = useAccount();
  const { data: signer } = useSigner();
  const [petId, setPetId] = useState(0);

  let exportedCount;
  let name;
  let age;
  let species;
  let vacced;
  let creationdateBlock;
  let creationdate;
  let adoptiondate;
  let owner;
  const [pets] = useState<Pet[]>([]);
  type Pet = {
    id: string;
    name: string;
    age: string;
    species: string;
    vacced: string;
    date: string;
    adoptiondate: number;
    owner: string;
  };

  const contractABI = ABI;
  const contractAddress = "0x25d01f0bc600690a11e44d593c34265d50eaeab3";
  const [myData, setMyData] = useState(null);
  const petCount = useContractRead({
    address: "0x25d01f0bc600690a11e44d593c34265d50eaeab3",
    abi: ABI,
    functionName: "totalPets",
  });
  exportedCount = Number(petCount.data);

  const provider = new ethers.providers.JsonRpcProvider(
    "https://rpc-mumbai.maticvigil.com"
  );
  /*
  const { config, isFetching } = usePrepareContractWrite({
    address: "0x25d01F0bc600690A11E44D593C34265d50eAEAb3",
    abi: ABI,
    functionName: "adoptPet",
    args: [petId],
  });

  const { data, error, write } = useContractWrite(config);

  const { isLoading, isSuccess, isError } = useWaitForTransaction({
    hash: data?.hash,
  });
*/

  const { data, isLoading, isSuccess, write } = useContractWrite({
    mode: "recklesslyUnprepared",
    address: "0x25d01F0bc600690A11E44D593C34265d50eAEAb3",
    abi: ABI,
    functionName: "adoptPet",
    args: [petId],
  });

  const handleAdopt = (arg: number) => {
    setPetId(Number(arg));
  };

  useEffect(() => {
    console.log(petId);
    write();
  }, [petId]);

  const contract = new ethers.Contract(contractAddress, contractABI, provider);

  useEffect(() => {
    async function fetchData() {
      for (let i = 0; i < exportedCount; i++) {
        const ss = await contract.pets(i);

        setMyData(ss);

        let a = ss;

        name = a?.name;
        age = a?.age;
        species = a?.species;
        vacced = String(a?.vaccinated);
        creationdateBlock = Number(a?.createdAt);
        creationdate = new Date(creationdateBlock * 1000).toLocaleDateString(
          "en-US"
        );
        adoptiondate = Number(a?.adoptedAt);
        owner = a?.currentOwner;

        pets.push({
          id: i.toString(),
          name: name.toString(),
          age: age.toString(),
          species: species.toString(),
          vacced: vacced.toString(),
          date: creationdate.toString(),
          adoptiondate: adoptiondate,
          owner: owner.toString(),
        });
      }
    }

    if (pets.length < exportedCount) {
      fetchData();
    }
  }, [exportedCount]);

  const petTable = pets.map((Pets) => {
    const dugme = () => {
      /*   if (isError) {
        return <div>ERROR</div>;
      }

      if (isLoading) {
        return <div>adopting in progress</div>;
      }
      if (isSuccess) {
        return <div>adopting successful</div>;
      }*/

      if (Pets.adoptiondate == 0 && Pets.owner != address && isConnected) {
        return (
          <div>
            <button
              class="butt"
              onClick={() => {
                handleAdopt(Pets.id);
              }}
            >
              ADOPT
            </button>
            {isLoading && <p> Is loading </p>}
          </div>
        );
      } else
        return (
          <div>
            <button class="dissabledbutt">ADOPT</button>
          </div>
        );
    };

    return (
      <div>
        <div class="elements">
          <p>{Pets.id}</p>
          <p>{Pets.name}</p>
          <p>{Pets.age}</p>
          <p>{Pets.species}</p>
          <p>{Pets.vacced}</p>
          <p>{Pets.date}</p>
          <p>{dugme()}</p>
        </div>
      </div>
    );
  });

  return (
    <div>
      <div>{petTable}</div>
    </div>
  );
}

export default FullTable;
